import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertResumeSchema, insertApplicationSchema, insertInterviewSchema } from "@shared/schema";
import { analyzeResume, optimizeResume, generateCoverLetter, calculateJobMatch, generateInterviewQuestions } from "./services/openai";
import { scrapeJobs } from "./services/jobScraper";
import { sendApplicationEmail, generateApplicationEmailTemplate } from "./services/emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Resume routes
  app.post("/api/resumes", async (req, res) => {
    try {
      const resumeData = insertResumeSchema.parse(req.body);
      const resume = await storage.createResume(resumeData);
      
      // Analyze resume with AI
      if (resumeData.content) {
        const analysis = await analyzeResume(resumeData.content);
        await storage.updateResume(resume.id, { 
          aiAnalysis: analysis,
          isOptimized: false
        });
      }
      
      res.json(resume);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/resumes", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const resumes = await storage.getResumesByUserId(userId);
      res.json(resumes);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/resumes/:id/optimize", async (req, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const { jobDescription } = req.body;
      
      const resume = await storage.getResume(resumeId);
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const optimizedContent = await optimizeResume(resume.content, jobDescription);
      const updatedResume = await storage.updateResume(resumeId, {
        content: optimizedContent,
        isOptimized: true
      });
      
      res.json(updatedResume);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Job discovery routes
  app.post("/api/jobs/scrape", async (req, res) => {
    try {
      const { keywords, location, maxJobs = 20 } = req.body;
      
      if (!keywords || !Array.isArray(keywords)) {
        return res.status(400).json({ message: "Keywords array is required" });
      }
      
      const scrapedJobs = await scrapeJobs({ keywords, location, maxJobs });
      
      // Save jobs to storage
      const savedJobs = [];
      for (const jobData of scrapedJobs) {
        const job = await storage.createJob(jobData);
        savedJobs.push(job);
      }
      
      res.json(savedJobs);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/jobs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const jobs = await storage.getJobs(limit, offset);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/jobs/search", async (req, res) => {
    try {
      const { q: query, location } = req.query;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const jobs = await storage.searchJobs(query as string, location as string);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Job matching routes
  app.post("/api/jobs/:jobId/match", async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      const { resumeId, userId } = req.body;
      
      const job = await storage.getJob(jobId);
      const resume = await storage.getResume(resumeId);
      
      if (!job || !resume) {
        return res.status(404).json({ message: "Job or resume not found" });
      }
      
      const matchResult = await calculateJobMatch(resume.content, job.description);
      
      const jobMatch = await storage.createJobMatch({
        userId,
        jobId,
        resumeId,
        matchScore: matchResult.score,
        matchReasons: matchResult
      });
      
      res.json(jobMatch);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/matches", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const matches = await storage.getJobMatchesByUserId(userId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Application routes
  app.post("/api/applications", async (req, res) => {
    try {
      const applicationData = insertApplicationSchema.parse(req.body);
      const application = await storage.createApplication(applicationData);
      res.json(application);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/applications", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const applications = await storage.getApplicationsByUserId(userId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/applications/:id/status", async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const { status } = req.body;
      
      const updatedApplication = await storage.updateApplicationStatus(applicationId, status);
      if (!updatedApplication) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      res.json(updatedApplication);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/applications/:id/cover-letter", async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const application = await storage.getApplication(applicationId);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      const job = await storage.getJob(application.jobId);
      const resume = await storage.getResume(application.resumeId);
      
      if (!job || !resume) {
        return res.status(404).json({ message: "Job or resume not found" });
      }
      
      const coverLetter = await generateCoverLetter(
        resume.content,
        job.description,
        job.company
      );
      
      res.json({ coverLetter });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Interview routes
  app.post("/api/interviews", async (req, res) => {
    try {
      const interviewData = insertInterviewSchema.parse(req.body);
      const interview = await storage.createInterview(interviewData);
      res.json(interview);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/interviews", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const interviews = await storage.getInterviewsByUserId(userId);
      res.json(interviews);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/interviews/upcoming", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const interviews = await storage.getUpcomingInterviews(userId);
      res.json(interviews);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/interviews/questions", async (req, res) => {
    try {
      const { jobDescription, resumeText } = req.body;
      
      if (!jobDescription || !resumeText) {
        return res.status(400).json({ message: "Job description and resume text are required" });
      }
      
      const questions = await generateInterviewQuestions(jobDescription, resumeText);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Analytics routes
  app.get("/api/analytics/stats", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Email application route
  app.post("/api/applications/:id/send-email", async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const { recipientEmail, coverLetter } = req.body;
      
      const application = await storage.getApplication(applicationId);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      const job = await storage.getJob(application.jobId);
      const resume = await storage.getResume(application.resumeId);
      
      if (!job || !resume) {
        return res.status(404).json({ message: "Job or resume not found" });
      }
      
      const emailTemplate = generateApplicationEmailTemplate(
        "Hiring Manager",
        job.title,
        job.company,
        coverLetter
      );
      
      const success = await sendApplicationEmail({
        to: recipientEmail,
        subject: `Application for ${job.title} - ${job.company}`,
        body: emailTemplate,
        attachments: [{
          filename: 'resume.pdf',
          content: Buffer.from(resume.content).toString('base64'),
          contentType: 'application/pdf'
        }]
      });
      
      if (success) {
        await storage.updateApplicationStatus(applicationId, 'sent');
      }
      
      res.json({ success });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
