import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

export async function analyzeResume(resumeText: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional resume analyst. Analyze the resume and provide structured feedback including strengths, weaknesses, missing keywords, and suggestions for improvement. Respond with JSON in this format: { 'strengths': string[], 'weaknesses': string[], 'missingKeywords': string[], 'suggestions': string[], 'score': number }"
        },
        {
          role: "user",
          content: `Analyze this resume:\n\n${resumeText}`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error("Failed to analyze resume: " + (error as Error).message);
  }
}

export async function optimizeResume(resumeText: string, jobDescription: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional resume optimizer. Rewrite the resume to better match the job description while maintaining truthfulness. Focus on keywords, relevant experience, and formatting. Return the optimized resume text."
        },
        {
          role: "user",
          content: `Job Description:\n${jobDescription}\n\nCurrent Resume:\n${resumeText}\n\nPlease optimize this resume for the job.`
        }
      ],
    });

    return response.choices[0].message.content || resumeText;
  } catch (error) {
    throw new Error("Failed to optimize resume: " + (error as Error).message);
  }
}

export async function generateCoverLetter(resumeText: string, jobDescription: string, companyName: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional cover letter writer. Create a compelling, personalized cover letter based on the resume and job description. Keep it concise (3-4 paragraphs) and professional."
        },
        {
          role: "user",
          content: `Company: ${companyName}\n\nJob Description:\n${jobDescription}\n\nResume:\n${resumeText}\n\nPlease write a professional cover letter.`
        }
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    throw new Error("Failed to generate cover letter: " + (error as Error).message);
  }
}

export async function calculateJobMatch(resumeText: string, jobDescription: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a job matching expert. Compare the resume with the job description and provide a match score (0-100) with detailed reasons. Respond with JSON in this format: { 'score': number, 'reasons': string[], 'missingSkills': string[], 'matchedSkills': string[] }"
        },
        {
          role: "user",
          content: `Job Description:\n${jobDescription}\n\nResume:\n${resumeText}\n\nAnalyze the match between this resume and job.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error("Failed to calculate job match: " + (error as Error).message);
  }
}

export async function generateInterviewQuestions(jobDescription: string, resumeText: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an interview preparation expert. Generate relevant interview questions based on the job description and candidate's resume. Provide both technical and behavioral questions. Respond with JSON in this format: { 'technical': string[], 'behavioral': string[], 'situational': string[] }"
        },
        {
          role: "user",
          content: `Job Description:\n${jobDescription}\n\nResume:\n${resumeText}\n\nGenerate interview questions for this candidate.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error("Failed to generate interview questions: " + (error as Error).message);
  }
}
