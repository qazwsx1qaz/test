import { Search, Plus, Bell, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface TopNavProps {
  onMenuClick?: () => void;
  onNewApplication?: () => void;
}

export function TopNav({ onMenuClick, onNewApplication }: TopNavProps) {
  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow border-b border-gray-200">
      <Button
        variant="ghost"
        size="sm"
        className="px-4 border-r border-gray-200 text-gray-500 md:hidden"
        onClick={onMenuClick}
      >
        <Menu className="h-5 w-5" />
      </Button>
      
      <div className="flex-1 px-4 flex justify-between items-center">
        <div className="flex-1 flex">
          <div className="w-full flex md:ml-0">
            <div className="relative w-full max-w-lg">
              <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-3">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                className="block w-full h-full pl-10 pr-3 py-2 border-0 bg-transparent text-gray-900 placeholder-gray-500 focus:ring-0 focus:border-transparent"
                placeholder="Search jobs, companies..."
                type="search"
              />
            </div>
          </div>
        </div>
        
        <div className="ml-4 flex items-center md:ml-6 space-x-4">
          <Button 
            className="bg-primary hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center"
            onClick={onNewApplication}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Application
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="p-1 rounded-full text-gray-400 hover:text-gray-500"
          >
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
