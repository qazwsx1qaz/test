import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  Upload, 
  Search, 
  Heart, 
  Edit3, 
  Send, 
  MessageSquare, 
  TrendingUp, 
  Briefcase 
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: BarChart3 },
  { name: "Resume Upload", href: "/resume-upload", icon: Upload },
  { name: "Job Discovery", href: "/job-discovery", icon: Search },
  { name: "Job Matching", href: "/job-matching", icon: Heart },
  { name: "AI Resume Builder", href: "/ai-resume-builder", icon: Edit3 },
  { name: "Applications", href: "/applications", icon: Send },
  { name: "Interview Prep", href: "/interview-prep", icon: MessageSquare },
  { name: "Analytics", href: "/analytics", icon: TrendingUp },
];

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();

  return (
    <div className={cn("hidden md:flex md:w-64 md:flex-col", className)}>
      <div className="flex flex-col flex-grow pt-5 bg-white border-r border-gray-200 shadow-sm">
        {/* Logo */}
        <div className="flex items-center flex-shrink-0 px-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Briefcase className="h-4 w-4 text-white" />
            </div>
            <h1 className="ml-3 text-xl font-bold text-gray-900">JobFlow</h1>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <div className="mt-8 flex-grow flex flex-col">
          <nav className="flex-1 px-4 space-y-1">
            {navigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors",
                    isActive
                      ? "bg-primary text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                >
                  <item.icon 
                    className={cn(
                      "mr-3 h-4 w-4",
                      isActive ? "text-white" : "text-gray-400"
                    )} 
                  />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
        
        {/* User Profile */}
        <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
          <div className="flex items-center">
            <img 
              className="inline-block h-9 w-9 rounded-full object-cover" 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80" 
              alt="User profile" 
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">John Smith</p>
              <p className="text-xs font-medium text-gray-500">Pro Plan</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
