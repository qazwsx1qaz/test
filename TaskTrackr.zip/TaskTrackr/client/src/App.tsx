import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ResumeUpload from "@/pages/resume-upload";
import JobDiscovery from "@/pages/job-discovery";
import JobMatching from "@/pages/job-matching";
import AIResumeBuilder from "@/pages/ai-resume-builder";
import Applications from "@/pages/applications";
import InterviewPrep from "@/pages/interview-prep";
import Analytics from "@/pages/analytics";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/resume-upload" component={ResumeUpload} />
      <Route path="/job-discovery" component={JobDiscovery} />
      <Route path="/job-matching" component={JobMatching} />
      <Route path="/ai-resume-builder" component={AIResumeBuilder} />
      <Route path="/applications" component={Applications} />
      <Route path="/interview-prep" component={InterviewPrep} />
      <Route path="/analytics" component={Analytics} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
