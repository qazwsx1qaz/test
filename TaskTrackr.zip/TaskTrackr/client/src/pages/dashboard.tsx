import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Send, 
  Clock, 
  Calendar, 
  Target, 
  CheckCircle, 
  RefreshCw,
  Upload,
  Search as SearchIcon,
  Lightbulb,
  TrendingUp,
  Video
} from "lucide-react";
import { Link } from "wouter";

const mockUserId = 1; // In a real app, this would come from auth context

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/analytics/stats", mockUserId],
    queryFn: () => fetch(`/api/analytics/stats?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: applications, isLoading: applicationsLoading } = useQuery({
    queryKey: ["/api/applications", mockUserId],
    queryFn: () => fetch(`/api/applications?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: upcomingInterviews, isLoading: interviewsLoading } = useQuery({
    queryKey: ["/api/interviews/upcoming", mockUserId],
    queryFn: () => fetch(`/api/interviews/upcoming?userId=${mockUserId}`).then(res => res.json())
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "under_review": return "secondary";
      case "interview_scheduled": return "default";
      case "applied": return "outline";
      case "rejected": return "destructive";
      case "offered": return "default";
      default: return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "under_review": return "Under Review";
      case "interview_scheduled": return "Interview Scheduled";
      case "applied": return "Applied";
      case "rejected": return "Rejected";
      case "offered": return "Offered";
      default: return status;
    }
  };

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        {/* Dashboard Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Welcome back, John!</h1>
          <p className="mt-1 text-sm text-gray-600">Track your job application progress and discover new opportunities.</p>
        </div>

        {/* Progress Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Send className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <div className="ml-4 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Applications Sent</dt>
                    <dd className="text-lg font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.applicationsSent || 0}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-yellow-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Clock className="h-4 w-4 text-yellow-600" />
                  </div>
                </div>
                <div className="ml-4 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Pending Responses</dt>
                    <dd className="text-lg font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.pendingResponses || 0}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Calendar className="h-4 w-4 text-green-600" />
                  </div>
                </div>
                <div className="ml-4 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Interviews Scheduled</dt>
                    <dd className="text-lg font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.interviewsScheduled || 0}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-purple-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Target className="h-4 w-4 text-purple-600" />
                  </div>
                </div>
                <div className="ml-4 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Response Rate</dt>
                    <dd className="text-lg font-semibold text-gray-900">
                      {statsLoading ? "..." : `${stats?.responseRate || 0}%`}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Application Pipeline */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Application Pipeline</h3>
                <p className="mt-1 text-sm text-gray-500">Track your applications through each stage</p>
              </div>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-8 h-8 bg-secondary rounded-full">
                        <CheckCircle className="h-4 w-4 text-white" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">Resume Optimized</p>
                        <p className="text-xs text-gray-500">AI analysis complete</p>
                      </div>
                    </div>
                    <span className="text-xs text-secondary font-medium">Completed</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-8 h-8 bg-secondary rounded-full">
                        <CheckCircle className="h-4 w-4 text-white" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">Jobs Discovered</p>
                        <p className="text-xs text-gray-500">New opportunities found</p>
                      </div>
                    </div>
                    <span className="text-xs text-secondary font-medium">Completed</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-full">
                        <RefreshCw className="h-4 w-4 text-white animate-spin-slow" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">Applications Being Sent</p>
                        <p className="text-xs text-gray-500">Applications in progress</p>
                      </div>
                    </div>
                    <span className="text-xs text-primary font-medium">In Progress</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-8 h-8 bg-gray-200 rounded-full">
                        <Clock className="h-4 w-4 text-gray-400" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-500">Interview Preparation</p>
                        <p className="text-xs text-gray-400">Waiting for responses</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-400 font-medium">Pending</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Applications */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">Recent Applications</h3>
                  <Link href="/applications">
                    <Button variant="link" className="text-primary hover:text-blue-700 text-sm font-medium p-0">
                      View all
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="divide-y divide-gray-200">
                {applicationsLoading ? (
                  <div className="px-6 py-4 text-center text-gray-500">Loading applications...</div>
                ) : applications?.length > 0 ? (
                  applications.slice(0, 3).map((application: any) => (
                    <div key={application.id} className="px-6 py-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center min-w-0 flex-1">
                          <div className="flex-shrink-0">
                            <img 
                              className="h-10 w-10 rounded-lg object-cover border border-gray-200" 
                              src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80" 
                              alt="Company logo" 
                            />
                          </div>
                          <div className="ml-4 min-w-0 flex-1">
                            <p className="text-sm font-medium text-gray-900 truncate">Job Application</p>
                            <p className="text-sm text-gray-500 truncate">Applied recently</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={getStatusBadgeVariant(application.status)}>
                            {getStatusLabel(application.status)}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {new Date(application.appliedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="px-6 py-8 text-center">
                    <Send className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">No applications yet</p>
                    <p className="text-xs text-gray-400 mt-1">Start by uploading your resume</p>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Quick Actions</h3>
              </div>
              <CardContent className="p-6 space-y-4">
                <Link href="/resume-upload">
                  <Button variant="outline" className="w-full justify-start">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload New Resume
                  </Button>
                </Link>
                <Link href="/job-discovery">
                  <Button className="w-full justify-start">
                    <SearchIcon className="mr-2 h-4 w-4" />
                    Find Matching Jobs
                  </Button>
                </Link>
                <Link href="/interview-prep">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Mock Interview
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">AI Recommendations</h3>
                <p className="mt-1 text-sm text-gray-500">Personalized suggestions to improve your success rate</p>
              </div>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="w-6 h-6 bg-accent bg-opacity-10 rounded-full flex items-center justify-center">
                      <Lightbulb className="h-3 w-3 text-accent" />
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-gray-900 font-medium">Optimize Your Resume</p>
                    <p className="text-xs text-gray-500 mt-1">Add more keywords to match job requirements better.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="w-6 h-6 bg-accent bg-opacity-10 rounded-full flex items-center justify-center">
                      <Target className="h-3 w-3 text-accent" />
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-gray-900 font-medium">Follow Up Reminder</p>
                    <p className="text-xs text-gray-500 mt-1">Consider sending follow-up emails for pending applications.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="w-6 h-6 bg-accent bg-opacity-10 rounded-full flex items-center justify-center">
                      <TrendingUp className="h-3 w-3 text-accent" />
                    </div>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-gray-900 font-medium">Peak Application Time</p>
                    <p className="text-xs text-gray-500 mt-1">Tuesday mornings show higher response rates.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Interviews */}
            <Card>
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Upcoming Interviews</h3>
              </div>
              <CardContent className="p-6">
                {interviewsLoading ? (
                  <div className="text-center text-gray-500">Loading interviews...</div>
                ) : upcomingInterviews?.length > 0 ? (
                  <div className="space-y-4">
                    {upcomingInterviews.map((interview: any) => (
                      <div key={interview.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center">
                          <div className="flex-shrink-0">
                            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                              <Video className="h-4 w-4 text-white" />
                            </div>
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900">Interview Scheduled</p>
                            <p className="text-xs text-gray-500">
                              {new Date(interview.scheduledAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <Button size="sm" variant="link" className="text-primary hover:text-blue-700">
                          Prepare
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-gray-500">No interviews scheduled</p>
                    <Link href="/interview-prep">
                      <Button variant="link" className="mt-2 text-primary hover:text-blue-700 text-sm">
                        Schedule Mock Interview
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
