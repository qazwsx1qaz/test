import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

const mockUserId = 1;

export default function ResumeUpload() {
  const [fileName, setFileName] = useState("");
  const [content, setContent] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: resumes, isLoading } = useQuery({
    queryKey: ["/api/resumes", mockUserId],
    queryFn: () => fetch(`/api/resumes?userId=${mockUserId}`).then(res => res.json())
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: { fileName: string; content: string }) => {
      const response = await apiRequest("POST", "/api/resumes", {
        userId: mockUserId,
        fileName: data.fileName,
        content: data.content,
        parsedData: null,
        isOptimized: false,
        aiAnalysis: null
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Resume uploaded successfully",
        description: "Your resume has been uploaded and is being analyzed by AI.",
      });
      setFileName("");
      setContent("");
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const optimizeMutation = useMutation({
    mutationFn: async ({ resumeId, jobDescription }: { resumeId: number; jobDescription: string }) => {
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/optimize`, {
        jobDescription
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Resume optimized",
        description: "Your resume has been optimized for better job matching.",
      });
    },
    onError: (error) => {
      toast({
        title: "Optimization failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        setContent(text);
      };
      reader.readAsText(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileName || !content) {
      toast({
        title: "Missing information",
        description: "Please select a file and ensure it has content.",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({ fileName, content });
  };

  const getAnalysisColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Resume Upload</h1>
          <p className="mt-1 text-sm text-gray-600">Upload and manage your resumes with AI-powered analysis and optimization.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="mr-2 h-5 w-5" />
                Upload New Resume
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="resume-file">Resume File</Label>
                  <Input
                    id="resume-file"
                    type="file"
                    accept=".txt,.pdf,.doc,.docx"
                    onChange={handleFileChange}
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Supported formats: TXT, PDF, DOC, DOCX
                  </p>
                </div>

                {fileName && (
                  <div>
                    <Label htmlFor="content">Resume Content</Label>
                    <Textarea
                      id="content"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Your resume content will appear here..."
                      className="mt-1 min-h-[200px]"
                    />
                  </div>
                )}

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={uploadMutation.isPending || !fileName || !content}
                >
                  {uploadMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Resume
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Resume List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="mr-2 h-5 w-5" />
                Your Resumes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                  <p className="mt-2 text-sm text-gray-500">Loading resumes...</p>
                </div>
              ) : resumes?.length > 0 ? (
                <div className="space-y-4">
                  {resumes.map((resume: any) => (
                    <div key={resume.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">{resume.fileName}</h4>
                        <div className="flex items-center space-x-2">
                          {resume.isOptimized ? (
                            <Badge variant="default" className="bg-green-100 text-green-800">
                              <CheckCircle className="mr-1 h-3 w-3" />
                              Optimized
                            </Badge>
                          ) : (
                            <Badge variant="secondary">
                              Not Optimized
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      {resume.aiAnalysis && (
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-600">AI Score:</span>
                            <span className={`font-medium ${getAnalysisColor(resume.aiAnalysis.score)}`}>
                              {resume.aiAnalysis.score}/100
                            </span>
                          </div>
                          
                          {resume.aiAnalysis.strengths?.length > 0 && (
                            <div>
                              <span className="text-gray-600">Strengths:</span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {resume.aiAnalysis.strengths.slice(0, 3).map((strength: string, index: number) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {strength}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {resume.aiAnalysis.suggestions?.length > 0 && (
                            <div>
                              <span className="text-gray-600">Top Suggestion:</span>
                              <p className="text-xs text-gray-500 mt-1">
                                {resume.aiAnalysis.suggestions[0]}
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div className="flex space-x-2 mt-3">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            const jobDesc = prompt("Enter a job description to optimize your resume for:");
                            if (jobDesc) {
                              optimizeMutation.mutate({ resumeId: resume.id, jobDescription: jobDesc });
                            }
                          }}
                          disabled={optimizeMutation.isPending}
                        >
                          {optimizeMutation.isPending ? (
                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                          ) : (
                            <AlertCircle className="mr-1 h-3 w-3" />
                          )}
                          Optimize
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">No resumes uploaded yet</p>
                  <p className="text-xs text-gray-400 mt-1">Upload your first resume to get started</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
