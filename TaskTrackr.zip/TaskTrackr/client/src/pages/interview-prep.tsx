import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  MessageSquare, 
  Calendar, 
  Video, 
  Phone, 
  Users, 
  Brain, 
  Lightbulb, 
  Clock,
  CheckCircle,
  Loader2,
  Plus
} from "lucide-react";

const mockUserId = 1;

export default function InterviewPrep() {
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const [jobDescription, setJobDescription] = useState("");
  const [generatedQuestions, setGeneratedQuestions] = useState<any>(null);
  const [newInterviewType, setNewInterviewType] = useState("video");
  const [newInterviewDate, setNewInterviewDate] = useState("");
  const [newInterviewNotes, setNewInterviewNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes", mockUserId],
    queryFn: () => fetch(`/api/resumes?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: interviews, isLoading: interviewsLoading } = useQuery({
    queryKey: ["/api/interviews", mockUserId],
    queryFn: () => fetch(`/api/interviews?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: upcomingInterviews } = useQuery({
    queryKey: ["/api/interviews/upcoming", mockUserId],
    queryFn: () => fetch(`/api/interviews/upcoming?userId=${mockUserId}`).then(res => res.json())
  });

  const generateQuestionsMutation = useMutation({
    mutationFn: async ({ jobDescription, resumeText }: { jobDescription: string; resumeText: string }) => {
      const response = await apiRequest("POST", "/api/interviews/questions", {
        jobDescription,
        resumeText
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedQuestions(data);
      toast({
        title: "Questions generated successfully",
        description: "AI has created personalized interview questions for you.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const scheduleInterviewMutation = useMutation({
    mutationFn: async (data: { applicationId: number; scheduledAt: string; type: string; notes?: string }) => {
      const response = await apiRequest("POST", "/api/interviews", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interviews"] });
      toast({
        title: "Interview scheduled",
        description: "Your interview has been added to your calendar.",
      });
      setNewInterviewDate("");
      setNewInterviewNotes("");
    },
    onError: (error) => {
      toast({
        title: "Scheduling failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerateQuestions = () => {
    if (!selectedResumeId) {
      toast({
        title: "No resume selected",
        description: "Please select a resume to generate questions for.",
        variant: "destructive",
      });
      return;
    }

    if (!jobDescription.trim()) {
      toast({
        title: "Missing job description",
        description: "Please provide a job description to generate relevant questions.",
        variant: "destructive",
      });
      return;
    }

    const selectedResume = resumes?.find((r: any) => r.id.toString() === selectedResumeId);
    if (!selectedResume) {
      toast({
        title: "Resume not found",
        description: "Selected resume could not be found.",
        variant: "destructive",
      });
      return;
    }

    generateQuestionsMutation.mutate({
      jobDescription: jobDescription.trim(),
      resumeText: selectedResume.content
    });
  };

  const handleScheduleMockInterview = () => {
    if (!newInterviewDate) {
      toast({
        title: "Missing date",
        description: "Please select a date and time for the mock interview.",
        variant: "destructive",
      });
      return;
    }

    scheduleInterviewMutation.mutate({
      applicationId: 0, // Mock interview doesn't need real application
      scheduledAt: newInterviewDate,
      type: "mock",
      notes: newInterviewNotes || "Mock interview session"
    });
  };

  const getInterviewTypeIcon = (type: string) => {
    switch (type) {
      case "video": return <Video className="h-4 w-4" />;
      case "phone": return <Phone className="h-4 w-4" />;
      case "in_person": return <Users className="h-4 w-4" />;
      case "mock": return <Brain className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getInterviewTypeLabel = (type: string) => {
    switch (type) {
      case "video": return "Video Call";
      case "phone": return "Phone Call";
      case "in_person": return "In Person";
      case "mock": return "Mock Interview";
      default: return type;
    }
  };

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Interview Preparation</h1>
          <p className="mt-1 text-sm text-gray-600">Prepare for interviews with AI-generated questions and manage your interview schedule.</p>
        </div>

        <Tabs defaultValue="preparation" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="preparation">Question Preparation</TabsTrigger>
            <TabsTrigger value="schedule">Interview Schedule</TabsTrigger>
            <TabsTrigger value="tips">Interview Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="preparation" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Question Generator */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="mr-2 h-5 w-5" />
                    AI Question Generator
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="resume-select">Select Resume</Label>
                    <Select value={selectedResumeId} onValueChange={setSelectedResumeId}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Choose a resume" />
                      </SelectTrigger>
                      <SelectContent>
                        {resumesLoading ? (
                          <SelectItem value="loading" disabled>Loading resumes...</SelectItem>
                        ) : resumes?.length > 0 ? (
                          resumes.map((resume: any) => (
                            <SelectItem key={resume.id} value={resume.id.toString()}>
                              {resume.fileName}
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="none" disabled>No resumes found</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="job-desc">Job Description</Label>
                    <Textarea
                      id="job-desc"
                      value={jobDescription}
                      onChange={(e) => setJobDescription(e.target.value)}
                      placeholder="Paste the job description here to generate relevant interview questions..."
                      className="mt-1 min-h-[120px]"
                    />
                  </div>

                  <Button 
                    onClick={handleGenerateQuestions}
                    disabled={!selectedResumeId || !jobDescription.trim() || generateQuestionsMutation.isPending}
                    className="w-full"
                  >
                    {generateQuestionsMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating Questions...
                      </>
                    ) : (
                      <>
                        <Brain className="mr-2 h-4 w-4" />
                        Generate Interview Questions
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Generated Questions Display */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Practice Questions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {generatedQuestions ? (
                    <div className="space-y-6">
                      {generatedQuestions.technical?.length > 0 && (
                        <div>
                          <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                            <Badge variant="outline" className="mr-2">Technical</Badge>
                            Questions
                          </h4>
                          <div className="space-y-3">
                            {generatedQuestions.technical.map((question: string, index: number) => (
                              <div key={index} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                                <p className="text-sm text-gray-800">{question}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {generatedQuestions.behavioral?.length > 0 && (
                        <div>
                          <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                            <Badge variant="outline" className="mr-2">Behavioral</Badge>
                            Questions
                          </h4>
                          <div className="space-y-3">
                            {generatedQuestions.behavioral.map((question: string, index: number) => (
                              <div key={index} className="p-3 bg-green-50 rounded-lg border border-green-200">
                                <p className="text-sm text-gray-800">{question}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {generatedQuestions.situational?.length > 0 && (
                        <div>
                          <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                            <Badge variant="outline" className="mr-2">Situational</Badge>
                            Questions
                          </h4>
                          <div className="space-y-3">
                            {generatedQuestions.situational.map((question: string, index: number) => (
                              <div key={index} className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                                <p className="text-sm text-gray-800">{question}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <MessageSquare className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No questions generated yet</p>
                      <p className="text-xs text-gray-400 mt-1">
                        Select a resume and provide a job description to get started
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Schedule Mock Interview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="mr-2 h-5 w-5" />
                    Schedule Mock Interview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="interview-type">Interview Type</Label>
                    <Select value={newInterviewType} onValueChange={setNewInterviewType}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="video">Video Call</SelectItem>
                        <SelectItem value="phone">Phone Call</SelectItem>
                        <SelectItem value="in_person">In Person</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="interview-date">Date & Time</Label>
                    <Input
                      id="interview-date"
                      type="datetime-local"
                      value={newInterviewDate}
                      onChange={(e) => setNewInterviewDate(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="interview-notes">Notes (Optional)</Label>
                    <Textarea
                      id="interview-notes"
                      value={newInterviewNotes}
                      onChange={(e) => setNewInterviewNotes(e.target.value)}
                      placeholder="Add any notes about this mock interview session..."
                      className="mt-1"
                    />
                  </div>

                  <Button 
                    onClick={handleScheduleMockInterview}
                    disabled={!newInterviewDate || scheduleInterviewMutation.isPending}
                    className="w-full"
                  >
                    {scheduleInterviewMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Scheduling...
                      </>
                    ) : (
                      <>
                        <Calendar className="mr-2 h-4 w-4" />
                        Schedule Mock Interview
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Upcoming Interviews */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="mr-2 h-5 w-5" />
                    Upcoming Interviews
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {interviewsLoading ? (
                    <div className="text-center py-4">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading interviews...</p>
                    </div>
                  ) : upcomingInterviews?.length > 0 ? (
                    <div className="space-y-3">
                      {upcomingInterviews.map((interview: any) => (
                        <div key={interview.id} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              {getInterviewTypeIcon(interview.type)}
                              <span className="font-medium text-gray-900">
                                {getInterviewTypeLabel(interview.type)}
                              </span>
                            </div>
                            <Badge variant="outline">
                              {new Date(interview.scheduledAt).toLocaleDateString()}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            {new Date(interview.scheduledAt).toLocaleString()}
                          </p>
                          {interview.notes && (
                            <p className="text-xs text-gray-500 mt-1">{interview.notes}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Calendar className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No upcoming interviews</p>
                      <p className="text-xs text-gray-400 mt-1">
                        Schedule a mock interview to practice
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tips" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* General Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="mr-2 h-5 w-5" />
                    General Interview Tips
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Research the Company</p>
                        <p className="text-xs text-gray-600">Know their mission, values, and recent news</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Prepare STAR Stories</p>
                        <p className="text-xs text-gray-600">Situation, Task, Action, Result examples</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Practice Out Loud</p>
                        <p className="text-xs text-gray-600">Rehearse answers to common questions</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Prepare Questions</p>
                        <p className="text-xs text-gray-600">Ask thoughtful questions about the role</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Test Your Setup</p>
                        <p className="text-xs text-gray-600">Check camera, microphone, and internet</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Technical Interview Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="mr-2 h-5 w-5" />
                    Technical Interview Tips
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Think Out Loud</p>
                        <p className="text-xs text-gray-600">Explain your thought process clearly</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Ask Clarifying Questions</p>
                        <p className="text-xs text-gray-600">Understand requirements before coding</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Start with Simple Solution</p>
                        <p className="text-xs text-gray-600">Then optimize if time permits</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Test Your Code</p>
                        <p className="text-xs text-gray-600">Walk through examples and edge cases</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Practice Coding</p>
                        <p className="text-xs text-gray-600">Use platforms like LeetCode or HackerRank</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Day of Interview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Day of Interview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-purple-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Arrive Early</p>
                        <p className="text-xs text-gray-600">Join 5-10 minutes before scheduled time</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-purple-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Dress Appropriately</p>
                        <p className="text-xs text-gray-600">Professional attire even for video calls</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-purple-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Stay Calm and Confident</p>
                        <p className="text-xs text-gray-600">Take deep breaths and be yourself</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="h-4 w-4 text-purple-600 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Follow Up</p>
                        <p className="text-xs text-gray-600">Send a thank you email within 24 hours</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Common Questions */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Common Questions to Practice
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-700">• Tell me about yourself</p>
                    <p className="text-gray-700">• Why do you want this job?</p>
                    <p className="text-gray-700">• What are your strengths and weaknesses?</p>
                    <p className="text-gray-700">• Describe a challenge you overcame</p>
                    <p className="text-gray-700">• Where do you see yourself in 5 years?</p>
                    <p className="text-gray-700">• Why are you leaving your current job?</p>
                    <p className="text-gray-700">• Do you have any questions for us?</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
