import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Edit3, Wand2, FileText, Loader2, Download, Copy, CheckCircle } from "lucide-react";

const mockUserId = 1;

export default function AIResumeBuilder() {
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const [jobDescription, setJobDescription] = useState("");
  const [optimizedContent, setOptimizedContent] = useState("");
  const [isOptimizing, setIsOptimizing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes", mockUserId],
    queryFn: () => fetch(`/api/resumes?userId=${mockUserId}`).then(res => res.json())
  });

  const optimizeMutation = useMutation({
    mutationFn: async ({ resumeId, jobDescription }: { resumeId: number; jobDescription: string }) => {
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/optimize`, {
        jobDescription
      });
      return response.json();
    },
    onSuccess: (data) => {
      setOptimizedContent(data.content);
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Resume optimized successfully",
        description: "Your resume has been tailored for the job description.",
      });
    },
    onError: (error) => {
      toast({
        title: "Optimization failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleOptimize = () => {
    if (!selectedResumeId) {
      toast({
        title: "No resume selected",
        description: "Please select a resume to optimize.",
        variant: "destructive",
      });
      return;
    }

    if (!jobDescription.trim()) {
      toast({
        title: "Missing job description",
        description: "Please provide a job description to optimize against.",
        variant: "destructive",
      });
      return;
    }

    optimizeMutation.mutate({
      resumeId: parseInt(selectedResumeId),
      jobDescription: jobDescription.trim()
    });
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(optimizedContent);
      toast({
        title: "Copied to clipboard",
        description: "The optimized resume has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Failed to copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  const downloadResume = () => {
    const blob = new Blob([optimizedContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'optimized-resume.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const selectedResume = resumes?.find((r: any) => r.id.toString() === selectedResumeId);

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">AI Resume Builder</h1>
          <p className="mt-1 text-sm text-gray-600">Use AI to optimize your resume for specific job descriptions and improve your matching score.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="space-y-6">
            {/* Resume Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  Select Resume
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="resume-select">Choose a resume to optimize</Label>
                  <Select value={selectedResumeId} onValueChange={setSelectedResumeId}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select a resume" />
                    </SelectTrigger>
                    <SelectContent>
                      {resumesLoading ? (
                        <SelectItem value="loading" disabled>Loading resumes...</SelectItem>
                      ) : resumes?.length > 0 ? (
                        resumes.map((resume: any) => (
                          <SelectItem key={resume.id} value={resume.id.toString()}>
                            <div className="flex items-center justify-between w-full">
                              <span>{resume.fileName}</span>
                              {resume.isOptimized && (
                                <Badge variant="default" className="ml-2">
                                  <CheckCircle className="mr-1 h-3 w-3" />
                                  Optimized
                                </Badge>
                              )}
                            </div>
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="none" disabled>No resumes found</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {selectedResume && (
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">{selectedResume.fileName}</h4>
                    {selectedResume.aiAnalysis && (
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Current AI Score:</span>
                          <Badge variant="outline">
                            {selectedResume.aiAnalysis.score}/100
                          </Badge>
                        </div>
                        {selectedResume.aiAnalysis.strengths?.length > 0 && (
                          <div>
                            <span className="text-gray-600 block mb-1">Strengths:</span>
                            <div className="flex flex-wrap gap-1">
                              {selectedResume.aiAnalysis.strengths.slice(0, 3).map((strength: string, index: number) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {strength}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Job Description Input */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Edit3 className="mr-2 h-5 w-5" />
                  Job Description
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div>
                  <Label htmlFor="job-description">Paste the job description here</Label>
                  <Textarea
                    id="job-description"
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Paste the full job description here. Include requirements, qualifications, and responsibilities..."
                    className="mt-1 min-h-[200px]"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    The more detailed the job description, the better the optimization will be.
                  </p>
                </div>

                <Button 
                  onClick={handleOptimize}
                  disabled={!selectedResumeId || !jobDescription.trim() || optimizeMutation.isPending}
                  className="w-full mt-4"
                >
                  {optimizeMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Optimizing Resume...
                    </>
                  ) : (
                    <>
                      <Wand2 className="mr-2 h-4 w-4" />
                      Optimize Resume
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Output Panel */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Wand2 className="mr-2 h-5 w-5" />
                    Optimized Resume
                  </CardTitle>
                  {optimizedContent && (
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={copyToClipboard}>
                        <Copy className="mr-1 h-3 w-3" />
                        Copy
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadResume}>
                        <Download className="mr-1 h-3 w-3" />
                        Download
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {optimizedContent ? (
                  <div>
                    <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                        <span className="text-sm font-medium text-green-800">
                          Resume optimized successfully!
                        </span>
                      </div>
                      <p className="text-xs text-green-600 mt-1">
                        Your resume has been tailored to match the job requirements better.
                      </p>
                    </div>
                    
                    <Textarea
                      value={optimizedContent}
                      onChange={(e) => setOptimizedContent(e.target.value)}
                      className="min-h-[400px] font-mono text-sm"
                      placeholder="Your optimized resume will appear here..."
                    />
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Wand2 className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-sm font-medium text-gray-900 mb-2">No optimized resume yet</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Select a resume and provide a job description to get started.
                    </p>
                    
                    <div className="space-y-2 text-xs text-gray-400">
                      <p>✨ AI will analyze the job requirements</p>
                      <p>🎯 Optimize keywords and phrases</p>
                      <p>📈 Improve your matching score</p>
                      <p>✅ Maintain accuracy and truthfulness</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Tips Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Optimization Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <p className="text-sm text-gray-600">
                    Include the complete job description for best results
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <p className="text-sm text-gray-600">
                    The AI will maintain factual accuracy while optimizing keywords
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <p className="text-sm text-gray-600">
                    Review and edit the optimized version before using
                  </p>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <p className="text-sm text-gray-600">
                    Save the optimized version as a new resume for specific applications
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
