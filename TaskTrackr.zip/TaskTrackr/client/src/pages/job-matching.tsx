import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Heart, Target, TrendingUp, Loader2, Building, MapPin, ExternalLink } from "lucide-react";

const mockUserId = 1;

export default function JobMatching() {
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes", mockUserId],
    queryFn: () => fetch(`/api/resumes?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: () => fetch("/api/jobs?limit=20").then(res => res.json())
  });

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ["/api/matches", mockUserId],
    queryFn: () => fetch(`/api/matches?userId=${mockUserId}`).then(res => res.json())
  });

  const matchMutation = useMutation({
    mutationFn: async (data: { jobId: number; resumeId: number }) => {
      const response = await apiRequest("POST", `/api/jobs/${data.jobId}/match`, {
        resumeId: data.resumeId,
        userId: mockUserId
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
      toast({
        title: "Job match calculated",
        description: "The compatibility score has been generated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Matching failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMatchJob = (jobId: number) => {
    if (!selectedResumeId) {
      toast({
        title: "No resume selected",
        description: "Please select a resume to match against jobs.",
        variant: "destructive",
      });
      return;
    }

    matchMutation.mutate({
      jobId,
      resumeId: parseInt(selectedResumeId)
    });
  };

  const getMatchColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getMatchBadgeVariant = (score: number) => {
    if (score >= 80) return "default";
    if (score >= 60) return "secondary";
    return "outline";
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get existing matches for jobs
  const getExistingMatch = (jobId: number) => {
    return matches?.find((match: any) => match.jobId === jobId);
  };

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Job Matching</h1>
          <p className="mt-1 text-sm text-gray-600">Find jobs that match your skills and experience using AI-powered analysis.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Controls */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="mr-2 h-5 w-5" />
                  Match Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Select Resume
                  </label>
                  <Select value={selectedResumeId} onValueChange={setSelectedResumeId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a resume" />
                    </SelectTrigger>
                    <SelectContent>
                      {resumesLoading ? (
                        <SelectItem value="loading" disabled>Loading...</SelectItem>
                      ) : resumes?.length > 0 ? (
                        resumes.map((resume: any) => (
                          <SelectItem key={resume.id} value={resume.id.toString()}>
                            {resume.fileName}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="none" disabled>No resumes found</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {selectedResumeId && (
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-700">
                      <Target className="inline mr-1 h-4 w-4" />
                      Resume selected. Click "Match" on any job to calculate compatibility.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Match Statistics */}
            {matches?.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="mr-2 h-5 w-5" />
                    Your Matches
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Total Matches:</span>
                      <span className="font-medium">{matches.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">High Match (80%+):</span>
                      <span className="font-medium text-green-600">
                        {matches.filter((m: any) => m.matchScore >= 80).length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Good Match (60-79%):</span>
                      <span className="font-medium text-yellow-600">
                        {matches.filter((m: any) => m.matchScore >= 60 && m.matchScore < 80).length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Low Match (&lt;60%):</span>
                      <span className="font-medium text-red-600">
                        {matches.filter((m: any) => m.matchScore < 60).length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Job Listings */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Heart className="mr-2 h-5 w-5" />
                    Available Jobs
                  </CardTitle>
                  <Badge variant="outline">
                    {jobs?.length || 0} jobs available
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {jobsLoading ? (
                  <div className="text-center py-8">
                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Loading jobs...</p>
                  </div>
                ) : jobs?.length > 0 ? (
                  <div className="space-y-4 max-h-[700px] overflow-y-auto">
                    {jobs.map((job: any) => {
                      const existingMatch = getExistingMatch(job.id);
                      
                      return (
                        <div key={job.id} className="border rounded-lg p-6 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="font-semibold text-gray-900 text-lg">{job.title}</h3>
                                {job.jobUrl && (
                                  <a 
                                    href={job.jobUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-primary hover:text-blue-700"
                                  >
                                    <ExternalLink className="h-4 w-4" />
                                  </a>
                                )}
                              </div>
                              
                              <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                                <div className="flex items-center">
                                  <Building className="mr-1 h-4 w-4" />
                                  {job.company}
                                </div>
                                {job.location && (
                                  <div className="flex items-center">
                                    <MapPin className="mr-1 h-4 w-4" />
                                    {job.location}
                                  </div>
                                )}
                                <span className="text-xs">
                                  Posted: {job.postedDate ? formatDate(job.postedDate) : 'Recently'}
                                </span>
                              </div>

                              <p className="text-sm text-gray-700 mb-4 line-clamp-3">
                                {job.description}
                              </p>

                              {job.requirements && (
                                <div className="mb-4">
                                  <h4 className="text-sm font-medium text-gray-900 mb-1">Requirements:</h4>
                                  <p className="text-sm text-gray-600 line-clamp-2">
                                    {job.requirements}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Match Score Section */}
                          {existingMatch ? (
                            <div className="border-t pt-4">
                              <div className="flex items-center justify-between mb-3">
                                <span className="text-sm font-medium text-gray-700">Match Score:</span>
                                <Badge variant={getMatchBadgeVariant(existingMatch.matchScore)}>
                                  <span className={getMatchColor(existingMatch.matchScore)}>
                                    {Math.round(existingMatch.matchScore)}%
                                  </span>
                                </Badge>
                              </div>
                              
                              <Progress 
                                value={existingMatch.matchScore} 
                                className="mb-3 h-2"
                              />

                              {existingMatch.matchReasons && (
                                <div className="space-y-2">
                                  {existingMatch.matchReasons.matchedSkills?.length > 0 && (
                                    <div>
                                      <span className="text-xs font-medium text-green-700">Matched Skills:</span>
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {existingMatch.matchReasons.matchedSkills.slice(0, 5).map((skill: string, index: number) => (
                                          <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700">
                                            {skill}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                  
                                  {existingMatch.matchReasons.missingSkills?.length > 0 && (
                                    <div>
                                      <span className="text-xs font-medium text-red-700">Missing Skills:</span>
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {existingMatch.matchReasons.missingSkills.slice(0, 3).map((skill: string, index: number) => (
                                          <Badge key={index} variant="outline" className="text-xs bg-red-50 text-red-700">
                                            {skill}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="border-t pt-4">
                              <Button
                                onClick={() => handleMatchJob(job.id)}
                                disabled={!selectedResumeId || matchMutation.isPending}
                                className="w-full"
                              >
                                {matchMutation.isPending ? (
                                  <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Calculating Match...
                                  </>
                                ) : (
                                  <>
                                    <Target className="mr-2 h-4 w-4" />
                                    Calculate Match Score
                                  </>
                                )}
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Heart className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">No jobs available</p>
                    <p className="text-xs text-gray-400 mt-1">
                      Try discovering new jobs first
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
