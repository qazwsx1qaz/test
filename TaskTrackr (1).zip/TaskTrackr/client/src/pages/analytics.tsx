import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  Target, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Calendar,
  Send,
  Eye,
  Loader2,
  BarChart3,
  PieChart,
  Activity
} from "lucide-react";

const mockUserId = 1;

export default function Analytics() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/analytics/stats", mockUserId],
    queryFn: () => fetch(`/api/analytics/stats?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: applications, isLoading: applicationsLoading } = useQuery({
    queryKey: ["/api/applications", mockUserId],
    queryFn: () => fetch(`/api/applications?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ["/api/matches", mockUserId],
    queryFn: () => fetch(`/api/matches?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: interviews } = useQuery({
    queryKey: ["/api/interviews", mockUserId],
    queryFn: () => fetch(`/api/interviews?userId=${mockUserId}`).then(res => res.json())
  });

  // Calculate additional analytics
  const getApplicationTrends = () => {
    if (!applications) return [];
    
    const last30Days = new Date();
    last30Days.setDate(last30Days.getDate() - 30);
    
    const recentApplications = applications.filter((app: any) => 
      new Date(app.appliedAt) >= last30Days
    );
    
    // Group by week
    const weeklyData = [];
    for (let i = 3; i >= 0; i--) {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - (i * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      const weekApplications = recentApplications.filter((app: any) => {
        const appDate = new Date(app.appliedAt);
        return appDate >= weekStart && appDate <= weekEnd;
      });
      
      weeklyData.push({
        week: `Week ${4-i}`,
        applications: weekApplications.length,
        responses: weekApplications.filter((app: any) => app.status !== 'applied').length
      });
    }
    
    return weeklyData;
  };

  const getStatusDistribution = () => {
    if (!applications) return [];
    
    const statusCounts = applications.reduce((acc: any, app: any) => {
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    }, {});
    
    return Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count: count as number,
      percentage: Math.round(((count as number) / applications.length) * 100)
    }));
  };

  const getMatchScoreDistribution = () => {
    if (!matches) return { high: 0, medium: 0, low: 0 };
    
    return matches.reduce((acc: any, match: any) => {
      if (match.matchScore >= 80) acc.high++;
      else if (match.matchScore >= 60) acc.medium++;
      else acc.low++;
      return acc;
    }, { high: 0, medium: 0, low: 0 });
  };

  const getAverageResponseTime = () => {
    if (!applications) return "N/A";
    
    const responsedApplications = applications.filter((app: any) => 
      app.status !== 'applied' && app.lastUpdated !== app.appliedAt
    );
    
    if (responsedApplications.length === 0) return "N/A";
    
    const totalDays = responsedApplications.reduce((acc: number, app: any) => {
      const applied = new Date(app.appliedAt);
      const updated = new Date(app.lastUpdated);
      const diffTime = Math.abs(updated.getTime() - applied.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return acc + diffDays;
    }, 0);
    
    return `${Math.round(totalDays / responsedApplications.length)} days`;
  };

  const getSuccessRate = () => {
    if (!applications || applications.length === 0) return 0;
    
    const positiveOutcomes = applications.filter((app: any) => 
      ['interview_scheduled', 'offered'].includes(app.status)
    ).length;
    
    return Math.round((positiveOutcomes / applications.length) * 100);
  };

  const weeklyTrends = getApplicationTrends();
  const statusDistribution = getStatusDistribution();
  const matchDistribution = getMatchScoreDistribution();

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="mt-1 text-sm text-gray-600">Track your job search performance and identify improvement opportunities.</p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="applications">Applications</TabsTrigger>
            <TabsTrigger value="matching">Job Matching</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                        <Send className="h-4 w-4 text-primary" />
                      </div>
                    </div>
                    <div className="ml-4 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Total Applications</dt>
                        <dd className="text-lg font-semibold text-gray-900">
                          {statsLoading ? "..." : stats?.applicationsSent || 0}
                        </dd>
                      </dl>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-green-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                        <Target className="h-4 w-4 text-green-600" />
                      </div>
                    </div>
                    <div className="ml-4 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Success Rate</dt>
                        <dd className="text-lg font-semibold text-gray-900">
                          {applicationsLoading ? "..." : `${getSuccessRate()}%`}
                        </dd>
                      </dl>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-blue-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                        <Clock className="h-4 w-4 text-blue-600" />
                      </div>
                    </div>
                    <div className="ml-4 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Avg Response Time</dt>
                        <dd className="text-lg font-semibold text-gray-900">
                          {applicationsLoading ? "..." : getAverageResponseTime()}
                        </dd>
                      </dl>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-purple-500 bg-opacity-10 rounded-lg flex items-center justify-center">
                        <Calendar className="h-4 w-4 text-purple-600" />
                      </div>
                    </div>
                    <div className="ml-4 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">Interviews</dt>
                        <dd className="text-lg font-semibold text-gray-900">
                          {statsLoading ? "..." : stats?.interviewsScheduled || 0}
                        </dd>
                      </dl>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Trends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5" />
                  Application Trends (Last 4 Weeks)
                </CardTitle>
              </CardHeader>
              <CardContent>
                {applicationsLoading ? (
                  <div className="text-center py-8">
                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Loading trends...</p>
                  </div>
                ) : weeklyTrends.length > 0 ? (
                  <div className="space-y-4">
                    {weeklyTrends.map((week, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <span className="text-sm font-medium text-gray-900 w-16">{week.week}</span>
                          <div className="flex-1 min-w-0">
                            <Progress value={(week.applications / 10) * 100} className="h-2" />
                          </div>
                        </div>
                        <div className="flex space-x-4 text-sm">
                          <span className="text-gray-600">{week.applications} sent</span>
                          <span className="text-green-600">{week.responses} responses</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BarChart3 className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">No application data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="applications" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Status Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChart className="mr-2 h-5 w-5" />
                    Application Status Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {applicationsLoading ? (
                    <div className="text-center py-8">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading distribution...</p>
                    </div>
                  ) : statusDistribution.length > 0 ? (
                    <div className="space-y-4">
                      {statusDistribution.map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Badge variant="outline" className="capitalize">
                              {item.status.replace('_', ' ')}
                            </Badge>
                            <span className="text-sm text-gray-600">{item.count} applications</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Progress value={item.percentage} className="w-20 h-2" />
                            <span className="text-sm font-medium text-gray-900 w-12">
                              {item.percentage}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <PieChart className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No applications to analyze</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Application Timeline */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="mr-2 h-5 w-5" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {applicationsLoading ? (
                    <div className="text-center py-8">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading activity...</p>
                    </div>
                  ) : applications?.length > 0 ? (
                    <div className="space-y-4 max-h-80 overflow-y-auto">
                      {applications.slice(0, 10).map((app: any, index: number) => (
                        <div key={index} className="flex items-center space-x-3 text-sm">
                          <div className="flex-shrink-0">
                            {app.status === 'applied' && <Clock className="h-4 w-4 text-gray-400" />}
                            {app.status === 'under_review' && <Eye className="h-4 w-4 text-blue-500" />}
                            {app.status === 'interview_scheduled' && <Calendar className="h-4 w-4 text-green-500" />}
                            {app.status === 'rejected' && <XCircle className="h-4 w-4 text-red-500" />}
                            {app.status === 'offered' && <CheckCircle className="h-4 w-4 text-green-600" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-gray-900 truncate">
                              Application status updated to <span className="font-medium">{app.status.replace('_', ' ')}</span>
                            </p>
                            <p className="text-gray-500 text-xs">
                              {new Date(app.lastUpdated).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Activity className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No recent activity</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="matching" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Match Score Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="mr-2 h-5 w-5" />
                    Job Match Scores
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {matchesLoading ? (
                    <div className="text-center py-8">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading matches...</p>
                    </div>
                  ) : matches?.length > 0 ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-green-600">{matchDistribution.high}</div>
                          <div className="text-sm text-gray-500">High Match (80%+)</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-yellow-600">{matchDistribution.medium}</div>
                          <div className="text-sm text-gray-500">Good Match (60-79%)</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-red-600">{matchDistribution.low}</div>
                          <div className="text-sm text-gray-500">Low Match (&lt;60%)</div>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">High Match Jobs</span>
                          <Progress value={(matchDistribution.high / matches.length) * 100} className="w-32 h-2" />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Good Match Jobs</span>
                          <Progress value={(matchDistribution.medium / matches.length) * 100} className="w-32 h-2" />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Low Match Jobs</span>
                          <Progress value={(matchDistribution.low / matches.length) * 100} className="w-32 h-2" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Target className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No job matches yet</p>
                      <p className="text-xs text-gray-400 mt-1">Start matching jobs to see analytics</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Top Matched Jobs */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="mr-2 h-5 w-5" />
                    Top Matched Jobs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {matchesLoading ? (
                    <div className="text-center py-8">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">Loading top matches...</p>
                    </div>
                  ) : matches?.length > 0 ? (
                    <div className="space-y-3 max-h-80 overflow-y-auto">
                      {matches
                        .sort((a: any, b: any) => b.matchScore - a.matchScore)
                        .slice(0, 8)
                        .map((match: any, index: number) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                Job Match #{match.jobId}
                              </p>
                              <p className="text-xs text-gray-500">
                                {new Date(match.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                            <Badge 
                              variant={match.matchScore >= 80 ? "default" : match.matchScore >= 60 ? "secondary" : "outline"}
                            >
                              {Math.round(match.matchScore)}%
                            </Badge>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <TrendingUp className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">No matches to show</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Performance Insights */}
              <Card>
                <CardHeader>
                  <CardTitle>Performance Insights</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-blue-900">Response Rate</p>
                        <p className="text-xs text-blue-600">
                          {statsLoading ? "Loading..." : `${stats?.responseRate || 0}% of applications get responses`}
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-blue-100 text-blue-800">
                        {statsLoading ? "..." : `${stats?.responseRate || 0}%`}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-green-900">Interview Rate</p>
                        <p className="text-xs text-green-600">
                          Percentage of applications that lead to interviews
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {applicationsLoading ? "..." : `${getSuccessRate()}%`}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-purple-900">Average Match Score</p>
                        <p className="text-xs text-purple-600">
                          How well your profile matches job requirements
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-purple-100 text-purple-800">
                        {matchesLoading ? "..." : matches?.length > 0 ? 
                          `${Math.round(matches.reduce((acc: number, m: any) => acc + m.matchScore, 0) / matches.length)}%` : 
                          "N/A"
                        }
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle>Improvement Recommendations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {getSuccessRate() < 10 && (
                      <div className="flex items-start p-3 bg-yellow-50 rounded-lg">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <div>
                          <p className="text-sm font-medium text-yellow-900">Improve Resume Optimization</p>
                          <p className="text-xs text-yellow-700">
                            Your success rate is low. Try optimizing your resume for specific job descriptions.
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {(stats?.responseRate || 0) < 20 && (
                      <div className="flex items-start p-3 bg-blue-50 rounded-lg">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <div>
                          <p className="text-sm font-medium text-blue-900">Apply to More Relevant Jobs</p>
                          <p className="text-xs text-blue-700">
                            Low response rate suggests you might be applying to jobs that aren't a good fit.
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {applications?.length > 0 && applications.length < 10 && (
                      <div className="flex items-start p-3 bg-green-50 rounded-lg">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        <div>
                          <p className="text-sm font-medium text-green-900">Increase Application Volume</p>
                          <p className="text-xs text-green-700">
                            Consider applying to more positions to increase your chances of success.
                          </p>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-start p-3 bg-purple-50 rounded-lg">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                      <div>
                        <p className="text-sm font-medium text-purple-900">Schedule Regular Follow-ups</p>
                        <p className="text-xs text-purple-700">
                          Following up on applications can improve response rates by 15-20%.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
