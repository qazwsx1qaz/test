import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Search, ExternalLink, MapPin, Building, Loader2, RefreshCw } from "lucide-react";

export default function JobDiscovery() {
  const [keywords, setKeywords] = useState("");
  const [location, setLocation] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: jobs, isLoading } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: () => fetch("/api/jobs?limit=50").then(res => res.json())
  });

  const scrapeMutation = useMutation({
    mutationFn: async (data: { keywords: string[]; location: string; maxJobs: number }) => {
      const response = await apiRequest("POST", "/api/jobs/scrape", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      toast({
        title: "Jobs discovered successfully",
        description: `Found ${data.length} new job opportunities.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Scraping failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const searchMutation = useMutation({
    mutationFn: async (data: { query: string; location?: string }) => {
      const params = new URLSearchParams({ q: data.query });
      if (data.location) params.append('location', data.location);
      const response = await fetch(`/api/jobs/search?${params}`);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/jobs"], data);
      toast({
        title: "Search completed",
        description: `Found ${data.length} matching jobs.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleScrape = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keywords.trim()) {
      toast({
        title: "Missing keywords",
        description: "Please enter at least one keyword to search for jobs.",
        variant: "destructive",
      });
      return;
    }

    const keywordArray = keywords.split(',').map(k => k.trim()).filter(k => k);
    scrapeMutation.mutate({
      keywords: keywordArray,
      location: location.trim(),
      maxJobs: 20
    });
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      toast({
        title: "Missing search query",
        description: "Please enter a search term.",
        variant: "destructive",
      });
      return;
    }

    searchMutation.mutate({
      query: searchQuery.trim(),
      location: location.trim() || undefined
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Job Discovery</h1>
          <p className="mt-1 text-sm text-gray-600">Discover new job opportunities through AI-powered web scraping and search.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Discovery Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Scrape New Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <RefreshCw className="mr-2 h-5 w-5" />
                  Discover New Jobs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleScrape} className="space-y-4">
                  <div>
                    <Label htmlFor="keywords">Keywords</Label>
                    <Input
                      id="keywords"
                      value={keywords}
                      onChange={(e) => setKeywords(e.target.value)}
                      placeholder="React, Frontend, JavaScript"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Separate multiple keywords with commas
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="San Francisco, CA"
                      className="mt-1"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={scrapeMutation.isPending}
                  >
                    {scrapeMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Discovering Jobs...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Discover Jobs
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Search Existing Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Search className="mr-2 h-5 w-5" />
                  Search Jobs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSearch} className="space-y-4">
                  <div>
                    <Label htmlFor="search">Search Query</Label>
                    <Input
                      id="search"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Frontend Developer"
                      className="mt-1"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    variant="outline" 
                    className="w-full"
                    disabled={searchMutation.isPending}
                  >
                    {searchMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Searching...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 h-4 w-4" />
                        Search
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Job Results */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Available Jobs</CardTitle>
                <p className="text-sm text-gray-500">
                  {jobs?.length || 0} jobs found
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8">
                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">Loading jobs...</p>
                  </div>
                ) : jobs?.length > 0 ? (
                  <div className="space-y-4 max-h-[600px] overflow-y-auto">
                    {jobs.map((job: any) => (
                      <div key={job.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-semibold text-gray-900">{job.title}</h3>
                              {job.jobUrl && (
                                <a 
                                  href={job.jobUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-primary hover:text-blue-700"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              )}
                            </div>
                            
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                              <div className="flex items-center">
                                <Building className="mr-1 h-4 w-4" />
                                {job.company}
                              </div>
                              {job.location && (
                                <div className="flex items-center">
                                  <MapPin className="mr-1 h-4 w-4" />
                                  {job.location}
                                </div>
                              )}
                            </div>

                            <p className="text-sm text-gray-700 mb-3 line-clamp-3">
                              {job.description}
                            </p>

                            {job.requirements && (
                              <div className="mb-3">
                                <h4 className="text-xs font-medium text-gray-900 mb-1">Requirements:</h4>
                                <p className="text-xs text-gray-600 line-clamp-2">
                                  {job.requirements}
                                </p>
                              </div>
                            )}

                            <div className="flex items-center justify-between">
                              <div className="flex space-x-2">
                                {job.salaryMin && job.salaryMax && (
                                  <Badge variant="outline">
                                    ${job.salaryMin.toLocaleString()} - ${job.salaryMax.toLocaleString()}
                                  </Badge>
                                )}
                              </div>
                              <span className="text-xs text-gray-500">
                                Posted: {job.postedDate ? formatDate(job.postedDate) : 'Recently'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Search className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">No jobs found</p>
                    <p className="text-xs text-gray-400 mt-1">
                      Try discovering new jobs or adjusting your search terms
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
