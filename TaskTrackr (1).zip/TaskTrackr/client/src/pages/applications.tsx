import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Send, 
  Building, 
  MapPin, 
  Calendar, 
  ExternalLink, 
  Mail, 
  FileText, 
  Loader2,
  Clock,
  CheckCircle,
  XCircle,
  Target
} from "lucide-react";

const mockUserId = 1;

export default function Applications() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [coverLetter, setCoverLetter] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: applications, isLoading } = useQuery({
    queryKey: ["/api/applications", mockUserId],
    queryFn: () => fetch(`/api/applications?userId=${mockUserId}`).then(res => res.json())
  });

  const { data: jobs } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: () => fetch("/api/jobs").then(res => res.json())
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ applicationId, status }: { applicationId: number; status: string }) => {
      const response = await apiRequest("PATCH", `/api/applications/${applicationId}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Status updated",
        description: "Application status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateCoverLetterMutation = useMutation({
    mutationFn: async (applicationId: number) => {
      const response = await apiRequest("POST", `/api/applications/${applicationId}/cover-letter`, {});
      return response.json();
    },
    onSuccess: (data) => {
      setCoverLetter(data.coverLetter);
      toast({
        title: "Cover letter generated",
        description: "AI has generated a personalized cover letter for this application.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sendEmailMutation = useMutation({
    mutationFn: async ({ applicationId, recipientEmail, coverLetter }: { applicationId: number; recipientEmail: string; coverLetter: string }) => {
      const response = await apiRequest("POST", `/api/applications/${applicationId}/send-email`, {
        recipientEmail,
        coverLetter
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Application sent",
        description: "Your application has been sent via email successfully.",
      });
      setSelectedApplication(null);
    },
    onError: (error) => {
      toast({
        title: "Send failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "sent": 
      case "under_review": return "secondary";
      case "interview_scheduled": return "default";
      case "applied": return "outline";
      case "rejected": return "destructive";
      case "offered": return "default";
      default: return "outline";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent":
      case "applied": return <Clock className="h-3 w-3" />;
      case "under_review": return <Target className="h-3 w-3" />;
      case "interview_scheduled": return <Calendar className="h-3 w-3" />;
      case "rejected": return <XCircle className="h-3 w-3" />;
      case "offered": return <CheckCircle className="h-3 w-3" />;
      default: return <Clock className="h-3 w-3" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "sent": return "Sent";
      case "under_review": return "Under Review";
      case "interview_scheduled": return "Interview Scheduled";
      case "applied": return "Applied";
      case "rejected": return "Rejected";
      case "offered": return "Offered";
      default: return status;
    }
  };

  const getJobForApplication = (application: any) => {
    return jobs?.find((job: any) => job.id === application.jobId);
  };

  const filteredApplications = applications?.filter((app: any) => {
    if (statusFilter === "all") return true;
    return app.status === statusFilter;
  }) || [];

  const statusCounts = applications?.reduce((acc: any, app: any) => {
    acc[app.status] = (acc[app.status] || 0) + 1;
    return acc;
  }, {}) || {};

  return (
    <DashboardLayout>
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Applications</h1>
          <p className="mt-1 text-sm text-gray-600">Track and manage your job applications throughout the entire process.</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-gray-900">{applications?.length || 0}</div>
                <div className="text-xs text-gray-500">Total</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-blue-600">{statusCounts.applied || 0}</div>
                <div className="text-xs text-gray-500">Applied</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-yellow-600">{statusCounts.under_review || 0}</div>
                <div className="text-xs text-gray-500">In Review</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-purple-600">{statusCounts.interview_scheduled || 0}</div>
                <div className="text-xs text-gray-500">Interviews</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-green-600">{statusCounts.offered || 0}</div>
                <div className="text-xs text-gray-500">Offers</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-red-600">{statusCounts.rejected || 0}</div>
                <div className="text-xs text-gray-500">Rejected</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter and Applications List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center">
                <Send className="mr-2 h-5 w-5" />
                Your Applications
              </CardTitle>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Applications</SelectItem>
                  <SelectItem value="applied">Applied</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                  <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                  <SelectItem value="offered">Offered</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                <p className="mt-2 text-sm text-gray-500">Loading applications...</p>
              </div>
            ) : filteredApplications.length > 0 ? (
              <div className="space-y-4">
                {filteredApplications.map((application: any) => {
                  const job = getJobForApplication(application);
                  return (
                    <div key={application.id} className="border rounded-lg p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            <img 
                              className="h-10 w-10 rounded-lg object-cover border border-gray-200" 
                              src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80" 
                              alt="Company logo" 
                            />
                            <div>
                              <h3 className="font-semibold text-gray-900">
                                {job?.title || "Job Position"}
                              </h3>
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center">
                                  <Building className="mr-1 h-4 w-4" />
                                  {job?.company || "Company"}
                                </div>
                                {job?.location && (
                                  <div className="flex items-center">
                                    <MapPin className="mr-1 h-4 w-4" />
                                    {job.location}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                            <div className="flex items-center">
                              <Calendar className="mr-1 h-4 w-4" />
                              Applied: {new Date(application.appliedAt).toLocaleDateString()}
                            </div>
                            <div className="flex items-center">
                              <Clock className="mr-1 h-4 w-4" />
                              Updated: {new Date(application.lastUpdated).toLocaleDateString()}
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Badge variant={getStatusBadgeVariant(application.status)}>
                                {getStatusIcon(application.status)}
                                <span className="ml-1">{getStatusLabel(application.status)}</span>
                              </Badge>
                              {job?.jobUrl && (
                                <a 
                                  href={job.jobUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-primary hover:text-blue-700"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              )}
                            </div>
                            
                            <div className="flex space-x-2">
                              <Select 
                                value={application.status} 
                                onValueChange={(status) => updateStatusMutation.mutate({ applicationId: application.id, status })}
                              >
                                <SelectTrigger className="w-[140px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="applied">Applied</SelectItem>
                                  <SelectItem value="sent">Sent</SelectItem>
                                  <SelectItem value="under_review">Under Review</SelectItem>
                                  <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                                  <SelectItem value="offered">Offered</SelectItem>
                                  <SelectItem value="rejected">Rejected</SelectItem>
                                </SelectContent>
                              </Select>

                              <Dialog 
                                open={selectedApplication?.id === application.id} 
                                onOpenChange={(open) => !open && setSelectedApplication(null)}
                              >
                                <DialogTrigger asChild>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => setSelectedApplication(application)}
                                  >
                                    <Mail className="mr-1 h-3 w-3" />
                                    Send Email
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-2xl">
                                  <DialogHeader>
                                    <DialogTitle>Send Application Email</DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <Label htmlFor="recipient">Recipient Email</Label>
                                      <Input
                                        id="recipient"
                                        type="email"
                                        value={recipientEmail}
                                        onChange={(e) => setRecipientEmail(e.target.value)}
                                        placeholder="hiring@company.com"
                                        className="mt-1"
                                      />
                                    </div>

                                    <div>
                                      <div className="flex items-center justify-between mb-2">
                                        <Label htmlFor="cover-letter">Cover Letter</Label>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => generateCoverLetterMutation.mutate(application.id)}
                                          disabled={generateCoverLetterMutation.isPending}
                                        >
                                          {generateCoverLetterMutation.isPending ? (
                                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                                          ) : (
                                            <FileText className="mr-1 h-3 w-3" />
                                          )}
                                          Generate AI Cover Letter
                                        </Button>
                                      </div>
                                      <Textarea
                                        id="cover-letter"
                                        value={coverLetter}
                                        onChange={(e) => setCoverLetter(e.target.value)}
                                        placeholder="Enter your cover letter here or generate one using AI..."
                                        className="min-h-[200px]"
                                      />
                                    </div>

                                    <div className="flex justify-end space-x-2">
                                      <Button 
                                        variant="outline" 
                                        onClick={() => setSelectedApplication(null)}
                                      >
                                        Cancel
                                      </Button>
                                      <Button
                                        onClick={() => sendEmailMutation.mutate({
                                          applicationId: application.id,
                                          recipientEmail,
                                          coverLetter
                                        })}
                                        disabled={!recipientEmail || !coverLetter || sendEmailMutation.isPending}
                                      >
                                        {sendEmailMutation.isPending ? (
                                          <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Sending...
                                          </>
                                        ) : (
                                          <>
                                            <Send className="mr-2 h-4 w-4" />
                                            Send Application
                                          </>
                                        )}
                                      </Button>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <Send className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-500">
                  {statusFilter === "all" ? "No applications yet" : `No ${statusFilter} applications`}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  Start applying to jobs to see them here
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
