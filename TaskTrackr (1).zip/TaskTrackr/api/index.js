// Vercel serverless function entry point
export { default } from '../dist/index.js';