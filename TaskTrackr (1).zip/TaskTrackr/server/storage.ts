import { 
  users, resumes, jobs, applications, interviews, jobMatches,
  type User, type InsertUser,
  type Resume, type InsertResume,
  type Job, type InsertJob,
  type Application, type InsertApplication,
  type Interview, type InsertInterview,
  type JobMatch, type InsertJobMatch
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Resume operations
  createResume(resume: InsertResume): Promise<Resume>;
  getResumesByUserId(userId: number): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  updateResume(id: number, updates: Partial<Resume>): Promise<Resume | undefined>;

  // Job operations
  createJob(job: InsertJob): Promise<Job>;
  getJobs(limit?: number, offset?: number): Promise<Job[]>;
  searchJobs(query: string, location?: string): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;

  // Application operations
  createApplication(application: InsertApplication): Promise<Application>;
  getApplicationsByUserId(userId: number): Promise<Application[]>;
  getApplication(id: number): Promise<Application | undefined>;
  updateApplicationStatus(id: number, status: string): Promise<Application | undefined>;

  // Interview operations
  createInterview(interview: InsertInterview): Promise<Interview>;
  getInterviewsByUserId(userId: number): Promise<Interview[]>;
  getUpcomingInterviews(userId: number): Promise<Interview[]>;

  // Job match operations
  createJobMatch(match: InsertJobMatch): Promise<JobMatch>;
  getJobMatchesByUserId(userId: number): Promise<JobMatch[]>;

  // Analytics
  getUserStats(userId: number): Promise<{
    applicationsSent: number;
    pendingResponses: number;
    interviewsScheduled: number;
    responseRate: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private resumes: Map<number, Resume>;
  private jobs: Map<number, Job>;
  private applications: Map<number, Application>;
  private interviews: Map<number, Interview>;
  private jobMatches: Map<number, JobMatch>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.resumes = new Map();
    this.jobs = new Map();
    this.applications = new Map();
    this.interviews = new Map();
    this.jobMatches = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async createResume(insertResume: InsertResume): Promise<Resume> {
    const id = this.currentId++;
    const resume: Resume = {
      ...insertResume,
      id,
      createdAt: new Date()
    };
    this.resumes.set(id, resume);
    return resume;
  }

  async getResumesByUserId(userId: number): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(
      resume => resume.userId === userId
    );
  }

  async getResume(id: number): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async updateResume(id: number, updates: Partial<Resume>): Promise<Resume | undefined> {
    const resume = this.resumes.get(id);
    if (resume) {
      const updated = { ...resume, ...updates };
      this.resumes.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentId++;
    const job: Job = {
      ...insertJob,
      id,
      scrapedAt: new Date()
    };
    this.jobs.set(id, job);
    return job;
  }

  async getJobs(limit = 50, offset = 0): Promise<Job[]> {
    const allJobs = Array.from(this.jobs.values());
    return allJobs.slice(offset, offset + limit);
  }

  async searchJobs(query: string, location?: string): Promise<Job[]> {
    const allJobs = Array.from(this.jobs.values());
    const lowerQuery = query.toLowerCase();
    
    return allJobs.filter(job => {
      const matchesQuery = job.title.toLowerCase().includes(lowerQuery) ||
                          job.description.toLowerCase().includes(lowerQuery) ||
                          job.company.toLowerCase().includes(lowerQuery);
      
      const matchesLocation = !location || 
                             job.location?.toLowerCase().includes(location.toLowerCase());
      
      return matchesQuery && matchesLocation;
    });
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.currentId++;
    const application: Application = {
      ...insertApplication,
      id,
      appliedAt: new Date(),
      lastUpdated: new Date()
    };
    this.applications.set(id, application);
    return application;
  }

  async getApplicationsByUserId(userId: number): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(
      app => app.userId === userId
    );
  }

  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async updateApplicationStatus(id: number, status: string): Promise<Application | undefined> {
    const application = this.applications.get(id);
    if (application) {
      const updated = { 
        ...application, 
        status, 
        lastUpdated: new Date() 
      };
      this.applications.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async createInterview(insertInterview: InsertInterview): Promise<Interview> {
    const id = this.currentId++;
    const interview: Interview = {
      ...insertInterview,
      id,
      createdAt: new Date()
    };
    this.interviews.set(id, interview);
    return interview;
  }

  async getInterviewsByUserId(userId: number): Promise<Interview[]> {
    const userApplications = await this.getApplicationsByUserId(userId);
    const applicationIds = userApplications.map(app => app.id);
    
    return Array.from(this.interviews.values()).filter(
      interview => applicationIds.includes(interview.applicationId)
    );
  }

  async getUpcomingInterviews(userId: number): Promise<Interview[]> {
    const interviews = await this.getInterviewsByUserId(userId);
    const now = new Date();
    
    return interviews.filter(interview => 
      interview.scheduledAt && 
      new Date(interview.scheduledAt) > now &&
      !interview.completed
    );
  }

  async createJobMatch(insertJobMatch: InsertJobMatch): Promise<JobMatch> {
    const id = this.currentId++;
    const jobMatch: JobMatch = {
      ...insertJobMatch,
      id,
      createdAt: new Date()
    };
    this.jobMatches.set(id, jobMatch);
    return jobMatch;
  }

  async getJobMatchesByUserId(userId: number): Promise<JobMatch[]> {
    return Array.from(this.jobMatches.values()).filter(
      match => match.userId === userId
    );
  }

  async getUserStats(userId: number): Promise<{
    applicationsSent: number;
    pendingResponses: number;
    interviewsScheduled: number;
    responseRate: number;
  }> {
    const applications = await this.getApplicationsByUserId(userId);
    const interviews = await this.getInterviewsByUserId(userId);
    
    const applicationsSent = applications.length;
    const pendingResponses = applications.filter(app => 
      app.status === 'applied' || app.status === 'under_review'
    ).length;
    const interviewsScheduled = interviews.filter(interview => 
      interview.scheduledAt && !interview.completed
    ).length;
    
    const responsesReceived = applications.filter(app => 
      app.status !== 'applied'
    ).length;
    const responseRate = applicationsSent > 0 ? 
      Math.round((responsesReceived / applicationsSent) * 100) : 0;

    return {
      applicationsSent,
      pendingResponses,
      interviewsScheduled,
      responseRate
    };
  }
}

export const storage = new MemStorage();
