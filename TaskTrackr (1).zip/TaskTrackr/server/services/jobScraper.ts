import { InsertJob } from '@shared/schema';

export interface ScrapingConfig {
  keywords: string[];
  location: string;
  maxJobs: number;
}

// Sample job database to simulate real job data
const SAMPLE_JOBS: InsertJob[] = [
  {
    title: "Senior Software Engineer",
    company: "TechCorp Inc",
    description: "We are looking for a Senior Software Engineer to join our team. You will be responsible for developing scalable web applications using React, Node.js, and PostgreSQL. Must have 5+ years of experience in full-stack development.",
    location: "San Francisco, CA",
    requirements: "5+ years experience with React, Node.js, PostgreSQL, TypeScript, AWS",
    salaryMin: 120000,
    salaryMax: 180000,
    jobUrl: "https://example.com/jobs/senior-software-engineer",
    postedDate: new Date(),
  },
  {
    title: "Full Stack Developer",
    company: "StartupXYZ",
    description: "Join our fast-growing startup as a Full Stack Developer. Work with modern technologies including React, Express.js, and MongoDB. Great opportunity for growth and learning.",
    location: "New York, NY",
    requirements: "3+ years experience with React, Express.js, MongoDB, JavaScript, Git",
    salaryMin: 90000,
    salaryMax: 130000,
    jobUrl: "https://example.com/jobs/full-stack-developer",
    postedDate: new Date(),
  },
  {
    title: "Frontend Developer",
    company: "DesignStudio",
    description: "We need a talented Frontend Developer to create beautiful and responsive user interfaces. Experience with React, TypeScript, and modern CSS frameworks required.",
    location: "Austin, TX",
    requirements: "React, TypeScript, CSS, SASS, Responsive Design, UI/UX principles",
    salaryMin: 75000,
    salaryMax: 110000,
    jobUrl: "https://example.com/jobs/frontend-developer",
    postedDate: new Date(),
  },
  {
    title: "Backend Engineer",
    company: "DataFlow Solutions",
    description: "Looking for a Backend Engineer to build robust APIs and microservices. Experience with Node.js, Python, and cloud technologies is essential.",
    location: "Seattle, WA",
    requirements: "Node.js, Python, PostgreSQL, Docker, AWS, RESTful APIs",
    salaryMin: 110000,
    salaryMax: 150000,
    jobUrl: "https://example.com/jobs/backend-engineer",
    postedDate: new Date(),
  },
  {
    title: "DevOps Engineer",
    company: "CloudTech",
    description: "Join our DevOps team to manage CI/CD pipelines and cloud infrastructure. Experience with AWS, Docker, and Kubernetes required.",
    location: "Denver, CO",
    requirements: "AWS, Docker, Kubernetes, CI/CD, Terraform, Linux",
    salaryMin: 100000,
    salaryMax: 140000,
    jobUrl: "https://example.com/jobs/devops-engineer",
    postedDate: new Date(),
  },
  {
    title: "React Developer",
    company: "WebSolutions Inc",
    description: "We're seeking a React Developer to build modern web applications. Strong knowledge of React ecosystem and state management required.",
    location: "Los Angeles, CA",
    requirements: "React, Redux, JavaScript, HTML5, CSS3, Jest, Git",
    salaryMin: 85000,
    salaryMax: 120000,
    jobUrl: "https://example.com/jobs/react-developer",
    postedDate: new Date(),
  },
  {
    title: "Node.js Developer",
    company: "API Masters",
    description: "Looking for a Node.js Developer to build scalable backend services. Experience with Express.js and database design is important.",
    location: "Chicago, IL",
    requirements: "Node.js, Express.js, MongoDB, PostgreSQL, RESTful APIs, Microservices",
    salaryMin: 95000,
    salaryMax: 135000,
    jobUrl: "https://example.com/jobs/nodejs-developer",
    postedDate: new Date(),
  },
  {
    title: "Software Engineer",
    company: "InnovateLab",
    description: "Join our engineering team to work on cutting-edge projects. We use modern technologies and follow agile development practices.",
    location: "Boston, MA",
    requirements: "JavaScript, TypeScript, React, Node.js, Agile, Problem-solving",
    salaryMin: 80000,
    salaryMax: 115000,
    jobUrl: "https://example.com/jobs/software-engineer",
    postedDate: new Date(),
  }
];

export async function scrapeJobs(config: ScrapingConfig): Promise<InsertJob[]> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  try {
    // Filter jobs based on keywords and location
    const filteredJobs = SAMPLE_JOBS.filter(job => {
      const keywordMatch = config.keywords.some(keyword => 
        job.title.toLowerCase().includes(keyword.toLowerCase()) ||
        job.description.toLowerCase().includes(keyword.toLowerCase()) ||
        job.requirements?.toLowerCase().includes(keyword.toLowerCase())
      );
      
      const locationMatch = !config.location || 
        job.location?.toLowerCase().includes(config.location.toLowerCase());
      
      return keywordMatch && locationMatch;
    });
    
    // Return limited number of jobs
    return filteredJobs.slice(0, config.maxJobs);
  } catch (error) {
    throw new Error("Failed to fetch jobs: " + (error as Error).message);
  }
}
