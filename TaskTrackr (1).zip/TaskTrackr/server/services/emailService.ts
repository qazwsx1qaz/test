import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export interface EmailData {
  to: string;
  subject: string;
  body: string;
  attachments?: Array<{
    filename: string;
    content: string;
    contentType: string;
  }>;
}

export async function sendApplicationEmail(emailData: EmailData): Promise<boolean> {
  try {
    const mailOptions = {
      from: process.env.SMTP_USER,
      to: emailData.to,
      subject: emailData.subject,
      html: emailData.body,
      attachments: emailData.attachments?.map(att => ({
        filename: att.filename,
        content: Buffer.from(att.content, 'base64'),
        contentType: att.contentType,
      })),
    };

    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Failed to send email:', error);
    return false;
  }
}

export function generateApplicationEmailTemplate(
  recipientName: string,
  position: string,
  company: string,
  coverLetter: string
): string {
  return `
    <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #2563EB;">Application for ${position}</h2>
          
          <p>Dear ${recipientName || 'Hiring Manager'},</p>
          
          <div style="margin: 20px 0;">
            ${coverLetter.split('\n').map(paragraph => `<p>${paragraph}</p>`).join('')}
          </div>
          
          <p>Please find my resume attached for your review.</p>
          
          <p>I look forward to hearing from you.</p>
          
          <p>Best regards,<br>
          [Your Name]</p>
          
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="font-size: 12px; color: #666; text-align: center;">
            This email was sent via JobFlow - AI-Powered Job Application Platform
          </p>
        </div>
      </body>
    </html>
  `;
}
