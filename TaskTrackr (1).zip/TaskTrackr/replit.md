# replit.md

## Overview

JobFlow is a comprehensive job search automation platform that combines AI-powered resume optimization, job discovery, application tracking, and interview preparation. The application uses a modern full-stack architecture with React/TypeScript frontend, Express.js backend, and PostgreSQL database with Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Middleware**: Custom logging and error handling middleware

### Database Design
- **Database**: PostgreSQL
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: Neon Database serverless connection
- **Tables**: Users, resumes, jobs, applications, interviews, job matches

## Key Components

### Resume Management
- Resume upload and content parsing
- AI-powered resume analysis using OpenAI GPT-4o
- Resume optimization for specific job descriptions
- Support for multiple resume versions per user

### Job Discovery & Scraping
- Automated job scraping from multiple sources (Indeed, LinkedIn)
- Puppeteer-based web scraping with headless browser automation
- Job search with keyword and location filtering
- Real-time job data collection and storage

### AI Integration
- **OpenAI GPT-4o** for resume analysis and optimization
- Cover letter generation based on job descriptions
- Job compatibility scoring and matching
- Interview question generation and preparation

### Application Tracking
- Comprehensive application status management
- Email integration for automated application sending
- Cover letter customization per application
- Application analytics and success metrics

### Interview Preparation
- AI-generated interview questions based on resume and job description
- Interview scheduling and management
- Preparation materials and tips
- Video/phone interview tracking

## Data Flow

1. **User onboarding**: Resume upload → AI analysis → Profile creation
2. **Job discovery**: Keyword search → Web scraping → Job storage → Matching algorithm
3. **Application process**: Job selection → Resume optimization → Cover letter generation → Application submission
4. **Interview preparation**: Interview scheduling → Question generation → Preparation materials
5. **Analytics**: Application tracking → Success metrics → Performance insights

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o model for text analysis, generation, and optimization
- **Email Service**: SMTP integration (Gmail) for automated application sending

### Web Scraping
- **Puppeteer**: Headless Chrome automation for job site scraping
- **Target Sites**: Indeed, LinkedIn job boards

### UI Components
- **Radix UI**: Accessible component primitives
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library

### Development Tools
- **Replit Integration**: Development environment optimization
- **ESBuild**: Production bundling
- **TypeScript**: Type safety across the stack

## Deployment Strategy

### Development
- Vite dev server for frontend hot reloading
- tsx for backend TypeScript execution
- Replit integration for cloud development

### Production Build
- Frontend: Vite build to `dist/public`
- Backend: ESBuild bundle to `dist/index.js`
- Single deployment artifact with static file serving

### Database Management
- Drizzle migrations for schema changes
- Environment-based configuration
- Connection pooling for production scalability

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 05, 2025. Initial setup